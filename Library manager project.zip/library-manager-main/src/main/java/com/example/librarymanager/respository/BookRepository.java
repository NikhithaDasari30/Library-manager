package com.example.librarymanager.respository;

import com.example.librarymanager.model.Book;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@EnableTransactionManagement
@Transactional
public class BookRepository {
    @Autowired(required = true)
    private SessionFactory sessionFactory;

    @Transactional
    public Book findById(long id) {
        Session session = sessionFactory.openSession();
        Book book = session.find(Book.class, id);

        session.close();
        return book;
    }

    @Transactional
    public List<Book> findByName(String name) {
        Session session = sessionFactory.openSession();
        Query query = session.createQuery("from Book where name like :name");
        query.setParameter("name", name+'%');
        List<Book> books = query.list();
        session.close();
        return books;
    }

    @Transactional
    public void saveOrUpdate(Book book) {
        Session session = sessionFactory.openSession();
        Transaction txn = session.beginTransaction();
        session.saveOrUpdate(book);
        txn.commit();
        session.close();
    }

    @Transactional
    public void delete(Book book) {
        Session session = sessionFactory.openSession();
        Transaction txn = session.beginTransaction();
        session.delete(session.contains(book) ? book : session.merge(book));
        txn.commit();
        session.close();
    }
}
