package com.example.librarymanager.controller;

import com.example.librarymanager.model.Book;
import com.example.librarymanager.model.User;
import com.example.librarymanager.service.IssueRecordService;
import com.example.librarymanager.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private IssueRecordService issueRecordService;

    @GetMapping("/")
    public String home() {
        return "user/home";
    }

    @GetMapping("/search")
    public String search(@RequestParam String search, @RequestParam long bookId, @RequestParam boolean forIssue , Model model) {
        model.addAttribute("users", userService.search(search));
        if(forIssue) {
            model.addAttribute("bookId", bookId);
        }
        model.addAttribute("forIssue", forIssue);
        return "user/view-users";
    }

    @GetMapping("/add")
    public String add(Model model) {
        model.addAttribute("user", new User());
        model.addAttribute("isNewUser", true);
        return "user/user-details";
    }

    @PostMapping("/save")
    public String save(@ModelAttribute("user") User user) {
        userService.saveOrUpdate(user);
        return "user/home";
    }

    @GetMapping("/issues")
    public String issues(@RequestParam long id, Model model) {
        model.addAttribute("issueRecords", issueRecordService.getActiveRecordByUserId(id));
        return "issue/view-issues";
    }
}
