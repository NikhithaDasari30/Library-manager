package com.example.librarymanager.service;

import com.example.librarymanager.model.Book;
import com.example.librarymanager.respository.BookRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    @Transactional
    public List<Book> search(String name) {
        return bookRepository.findByName(name);
    }

    @Transactional
    public void delete(long id) {
        bookRepository.delete(bookRepository.findById(id));
    }

    @Transactional
    public void saveOrUpdate(Book book) {
        bookRepository.saveOrUpdate(book);
    }


    @Transactional
    public void issue(Book book) {
        book.setAvailableCount(book.getAvailableCount() - 1);

        this.saveOrUpdate(book);
    }
    @Transactional
    public void returnBook(Book book) {
        book.setAvailableCount(book.getAvailableCount() + 1);

        this.saveOrUpdate(book);
    }

    @Transactional
    public Book findById(long id) {
        Book book = bookRepository.findById(id);

        return book;
    }
}

