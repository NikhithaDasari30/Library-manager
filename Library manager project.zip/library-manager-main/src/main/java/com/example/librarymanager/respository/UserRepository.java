package com.example.librarymanager.respository;

import com.example.librarymanager.model.Book;
import com.example.librarymanager.model.User;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@EnableTransactionManagement
@Transactional
public class UserRepository {
    @Autowired(required = true)
    private SessionFactory sessionFactory;

    @Transactional
    public User findById(long id) {
        Session session = sessionFactory.openSession();
        User user = session.find(User.class, id);

        session.close();
        return user;
    }

    @Transactional
    public List<User> findByName(String name) {
        Session session = sessionFactory.openSession();
        Query query = session.createQuery("from User where firstName like :name");
        query.setParameter("name", name+'%');
        List<User> users = query.list();
        session.close();
        return users;
    }

    @Transactional
    public void saveOrUpdateUser(User user) {
        Session session = sessionFactory.openSession();
        Transaction txn = session.beginTransaction();
        session.saveOrUpdate(user);
        txn.commit();
        session.close();
    }
}
