package com.example.librarymanager.respository;

import com.example.librarymanager.model.IssueRecord;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@EnableTransactionManagement
@Transactional
public class IssueRecordRepository {

    @Autowired(required = true)
    private SessionFactory sessionFactory;

    @Transactional
    public List<IssueRecord> getActiveIssuedRecordsByBook(long bookId) {
        Session session = sessionFactory.openSession();
        Query query = session.createQuery("from IssueRecord where book.id= :bookId and returnDate = null");
        query.setParameter("bookId", bookId);
        List<IssueRecord> issueRecords = query.list();
        session.close();
        return issueRecords;
    }

    @Transactional
    public List<IssueRecord> getActiveIssuedRecordsByUser(long userId) {
        Session session = sessionFactory.openSession();
        Query query = session.createQuery("from IssueRecord where user.id= :userId and returnDate = null");
        query.setParameter("userId", userId);
        List<IssueRecord> issueRecords = query.list();
        session.close();
        return issueRecords;
    }

    @Transactional
    public IssueRecord findById(long id){
        Session session = sessionFactory.openSession();
        IssueRecord issueRecord = session.find(IssueRecord.class, id);

        session.close();
        return issueRecord;
    }

    @Transactional
    public void saveOrUpdate(IssueRecord issueRecord) {
        Session session = sessionFactory.openSession();
        Transaction txn = session.beginTransaction();
        session.saveOrUpdate(issueRecord);
        txn.commit();
        session.close();
    }
}
