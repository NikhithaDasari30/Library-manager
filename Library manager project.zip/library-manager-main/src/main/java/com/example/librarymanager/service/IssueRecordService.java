package com.example.librarymanager.service;

import com.example.librarymanager.model.Book;
import com.example.librarymanager.model.IssueRecord;
import com.example.librarymanager.model.User;
import com.example.librarymanager.respository.IssueRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
public class IssueRecordService {
    @Autowired
    private IssueRecordRepository issueRecordRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private BookService bookService;

    @Transactional
    public List<IssueRecord> getActiveRecordByUserId(long userId) {
        return issueRecordRepository.getActiveIssuedRecordsByUser(userId);
    }

    @Transactional
    public List<IssueRecord> getActiveRecordByBookId(long bookId) {
        return issueRecordRepository.getActiveIssuedRecordsByBook(bookId);
    }

    @Transactional
    public IssueRecord findById(long id) {
        return issueRecordRepository.findById(id);
    }

    @Transactional
    public void createIssue(long userId, long bookId) {
        User user = userService.findByUser(userId);
        Book book = bookService.findById(bookId);
        IssueRecord issueRecord = new IssueRecord();
        issueRecord.setBook(book);
        issueRecord.setUser(user);
        issueRecord.setIssueDate(new Date());
        issueRecordRepository.saveOrUpdate(issueRecord);

        bookService.issue(book);
    }

    @Transactional
    public void returnIssueRecord(long id) {
        IssueRecord issueRecord = issueRecordRepository.findById(id);

        issueRecord.setReturnDate(new Date());
        issueRecordRepository.saveOrUpdate(issueRecord);

        bookService.returnBook(issueRecord.getBook());
    }
}
