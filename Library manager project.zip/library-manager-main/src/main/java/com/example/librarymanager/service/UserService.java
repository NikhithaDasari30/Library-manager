package com.example.librarymanager.service;

import com.example.librarymanager.model.User;
import com.example.librarymanager.respository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    @Transactional
    public User findByUser(long id) {
        return userRepository.findById(id);
    }

    @Transactional
    public List<User> search(String name) {
        return userRepository.findByName(name);
    }

    @Transactional
    public void saveOrUpdate(User user) {
        userRepository.saveOrUpdateUser(user);
    }
}
