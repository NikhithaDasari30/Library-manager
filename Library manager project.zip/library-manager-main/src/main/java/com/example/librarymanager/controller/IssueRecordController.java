package com.example.librarymanager.controller;


import com.example.librarymanager.service.IssueRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/issues")
public class IssueRecordController {

    @Autowired
    private IssueRecordService issueRecordService;

    @GetMapping("/user")
    public String recordsByUser(@RequestParam long userId, Model model) {
        model.addAttribute("records", issueRecordService.getActiveRecordByUserId(userId));
        return "records/user-records";
    }

    @GetMapping("/book")
    public String recordsByBook(@RequestParam long bookId, Model model) {
        model.addAttribute("records", issueRecordService.getActiveRecordByBookId(bookId));
        return "records/user-records";
    }

    @GetMapping("/create")
    public String create(@RequestParam long bookId, Model model) {
        model.addAttribute("forIssue", true);
        model.addAttribute("bookId", bookId);
        return "user/home";
    }

    @PostMapping("/submit")
    public String submit(@RequestParam long userId, @RequestParam long bookId) {
        issueRecordService.createIssue(userId, bookId);
        return "book/home";
    }

    @GetMapping("/return")
    public String returnRecord(@RequestParam long id) {
        issueRecordService.returnIssueRecord(id);

        return "book/home";
    }
}
