package com.example.librarymanager.controller;

import com.example.librarymanager.model.Book;
import com.example.librarymanager.service.BookService;
import com.example.librarymanager.service.IssueRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/book")
public class BookController {

    @Autowired
    private BookService bookService;

    @Autowired
    private IssueRecordService issueRecordService;

    @GetMapping("/")
    public String home() {
        return "book/home";
    }

    @GetMapping("/search")
    public String search(@RequestParam String search, Model model) {
        model.addAttribute("books", bookService.search(search));
        return "book/view-books";
    }


    @GetMapping("/add")
    public String add(Model model) {
        model.addAttribute("book", new Book());
        model.addAttribute("isNewBook", true);
        return "book/book-detail";
    }

    @GetMapping("/edit")
    public String edit(@RequestParam long id, Model model) {
        Book book = bookService.findById(id);
        model.addAttribute("book", book);
        model.addAttribute("isNewBook",false);
        return "book/book-detail";
    }
    
    @PostMapping("/save")
    public String save(@ModelAttribute("book") Book book) {
        if(book.getId() == 0) {
            book.setAvailableCount(book.getTotalCount());
        }
        else {
            Book old = bookService.findById(book.getId());
            book.setTotalCount(old.getTotalCount()+book.getAvailableCount()-old.getAvailableCount());
        }
        bookService.saveOrUpdate(book);
        return "book/home";
    }

    @GetMapping("/delete")
    public String delete(@RequestParam long id) {
        bookService.delete(id);
        return "book/home";
    }

    @PostMapping("/return")
    public String returnBook(@RequestParam long id, Model model) {
        model.addAttribute("issueRecords", issueRecordService.getActiveRecordByBookId(id));
        return "issue/view-issues";
    }
}
